import 'package:flutter_test/flutter_test.dart';
import 'package:audio_aesthetics_prism/main.dart';
void main(){testWidgets('Dashboard boots', (tester)async{
  await tester.pumpWidget(const AudioAestheticsApp());
  expect(find.text('AUDIO AESTHETICS'), findsWidgets);
});}
