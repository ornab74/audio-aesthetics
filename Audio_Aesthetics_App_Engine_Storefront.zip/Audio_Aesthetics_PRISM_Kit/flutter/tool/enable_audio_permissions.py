"""Idempotently patch `flutter create` generated runners for mic + localhost audio.
Run from flutter/: python tool/enable_audio_permissions.py
Review diffs before shipping: adjust platform security policies for your deployment.
"""
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]

def patch(path,fragment,marker,exists):
    if not path.exists():
        print('SKIPPED (not scaffolded):',path.relative_to(ROOT));return
    s=path.read_text()
    if exists in s:
        print('ALREADY SET:',path.relative_to(ROOT));return
    if marker not in s:raise RuntimeError(f'Could not find patch marker: {path}')
    path.write_text(s.replace(marker,fragment+marker,1))
    print('PATCHED:',path.relative_to(ROOT))

android=ROOT/'android/app/src/main/AndroidManifest.xml'
if android.exists():
    s=android.read_text()
    if 'android.permission.RECORD_AUDIO' not in s:
        match=re.search(r'<manifest\b[^>]*>',s)
        if match:
            extra='\n    <uses-permission android:name="android.permission.RECORD_AUDIO" />'
            if 'android.permission.INTERNET' not in s:
                extra+='\n    <uses-permission android:name="android.permission.INTERNET" />'
            s=s[:match.end()]+extra+s[match.end():]
    if 'android:networkSecurityConfig=' not in s:
        s=s.replace('<application','<application android:networkSecurityConfig="@xml/network_security_config"',1)
    android.write_text(s)
    config=ROOT/'android/app/src/main/res/xml/network_security_config.xml'
    config.parent.mkdir(parents=True,exist_ok=True)
    if not config.exists():config.write_text('''<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false" />
    <domain-config cleartextTrafficPermitted="true">
        <domain>127.0.0.1</domain><domain>localhost</domain>
    </domain-config>
</network-security-config>
''')
    print('PATCHED Android permissions / localhost-only cleartext policy')
else:print('Android runner not scaffolded; skipped')
for path in [ROOT/'ios/Runner/Info.plist',ROOT/'macos/Runner/Info.plist']:
    patch(path,'''    <key>NSMicrophoneUsageDescription</key>
    <string>Audio Aesthetics monitors your selected microphone for audio-quality alerts.</string>
''','</dict>','NSMicrophoneUsageDescription')
for path in [ROOT/'ios/Runner/Info.plist',ROOT/'macos/Runner/Info.plist']:
    patch(path,'''    <key>NSAppTransportSecurity</key>
    <dict><key>NSAllowsLocalNetworking</key><true/></dict>
''','</dict>','NSAppTransportSecurity')
for ent in [ROOT/'macos/Runner/DebugProfile.entitlements',ROOT/'macos/Runner/Release.entitlements']:
    net = ('    <key>com.apple.security.network.client</key>\n    <true/>\n'
           if ent.exists() and 'com.apple.security.network.client' not in ent.read_text() else '')
    patch(ent, '    <key>com.apple.security.device.audio-input</key>\n    <true/>\n'+net,
          '</dict>', 'com.apple.security.device.audio-input')
print('Done. iOS/macOS may still require LAN privacy prompts or HTTPS for remote API calls.')
