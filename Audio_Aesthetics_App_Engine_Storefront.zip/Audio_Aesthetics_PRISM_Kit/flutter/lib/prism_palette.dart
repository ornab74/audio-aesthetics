import 'package:flutter/material.dart';

class OrbitPalette {
  static const bg = Color(0xFF071716);
  static const panel = Color(0xFF112421);
  static const panelAlt = Color(0xFF192F2A);
  static const border = Color(0xFF536052);
  static const cream = Color(0xFFF0DCB2);
  static const muted = Color(0xFF9BAF9D);
  static const copper = Color(0xFFE2694E);
  static const teal = Color(0xFF5BD6B7);
  static const gold = Color(0xFFE4AF65);
  static const violet = Color(0xFF9F78D8);
  static const ringColors = <Color>[
    Color(0xFFE76559), Color(0xFFE89A4D), Color(0xFFE4BB5F),
    Color(0xFF70C7A7), Color(0xFF4DBFB5), Color(0xFF6AAAE0), Color(0xFFAB83E3),
  ];

  static ThemeData theme({bool light = false}) {
    final base = ThemeData(useMaterial3: true, brightness: Brightness.dark);
    final colorScheme = ColorScheme.fromSeed(
      seedColor: copper, brightness: Brightness.dark, surface: panel,
    ).copyWith(primary: copper, onPrimary: bg, secondary: teal,
      onSecondary: bg, surface: panel, onSurface: cream,
      outline: border, error: const Color(0xFFFF8A80));
    // Vintage OS type families: no font downloads or remote requests.
    // For exact platform parity a distributor can bundle licensed fonts.
    final body = base.textTheme.apply(
      fontFamily: 'American Typewriter',
      fontFamilyFallback: const ['Courier New', 'monospace'],
      bodyColor: cream, displayColor: cream,
    );
    const engraving = 'Copperplate';
    const engravingFallback = ['Copperplate Gothic Bold', 'Bookman Old Style', 'serif'];
    const tech = 'American Typewriter';
    const techFallback = ['Courier New', 'monospace'];
    final textTheme = body.copyWith(
      displayLarge: const TextStyle(fontFamily: engraving,fontFamilyFallback: engravingFallback,
        fontSize:39,fontWeight:FontWeight.w900,color:cream,letterSpacing:1.1),
      displayMedium: const TextStyle(fontFamily: engraving,fontFamilyFallback: engravingFallback,
        fontSize:30,fontWeight:FontWeight.w800,color:cream,letterSpacing:1.0),
      headlineLarge: const TextStyle(fontFamily: engraving,fontFamilyFallback: engravingFallback,
        fontSize:28,fontWeight:FontWeight.w800,color:copper,letterSpacing:.8),
      headlineMedium: const TextStyle(fontFamily: engraving,fontFamilyFallback: engravingFallback,
        fontSize:21,fontWeight:FontWeight.w800,color:cream,letterSpacing:.8),
      titleLarge: const TextStyle(fontFamily:tech,fontFamilyFallback:techFallback,
        fontSize:17,fontWeight:FontWeight.w700,color:cream,letterSpacing:1.2),
      titleMedium: const TextStyle(fontFamily:tech,fontFamilyFallback:techFallback,
        fontSize:14,fontWeight:FontWeight.bold,color:cream),
      bodyMedium: const TextStyle(fontFamily:tech,fontFamilyFallback:techFallback,
        fontSize:12,height:1.55,color:cream),
      bodySmall: const TextStyle(fontFamily:tech,fontFamilyFallback:techFallback,
        fontSize:11,height:1.45,color:muted),
      labelLarge: const TextStyle(fontFamily:tech,fontFamilyFallback:techFallback,
        fontSize:12,fontWeight:FontWeight.w700,letterSpacing:.4),
    );
    return base.copyWith(
      scaffoldBackgroundColor: bg, colorScheme: colorScheme, textTheme: textTheme,
      dividerColor: border.withOpacity(.45),
      cardTheme: CardThemeData(color: panel,borderOnForeground: true,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16),side: BorderSide(color: border.withOpacity(.65)))),
      appBarTheme: AppBarTheme(backgroundColor: bg, foregroundColor: cream, elevation: 0,
        titleTextStyle: textTheme.titleLarge),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panelAlt, isDense:true,
        hintStyle: textTheme.bodySmall,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),borderSide: const BorderSide(color: border)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),borderSide: const BorderSide(color: border)),
      ),
      filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
        foregroundColor: bg, backgroundColor: copper,
        padding: const EdgeInsets.symmetric(horizontal:20,vertical:15),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
      )),
      outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(
        foregroundColor: cream,side: const BorderSide(color:border),
        padding: const EdgeInsets.symmetric(horizontal:18,vertical:15),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
      )),
      chipTheme: base.chipTheme.copyWith(backgroundColor:panelAlt,
        side: const BorderSide(color:border),labelStyle: textTheme.bodySmall,
        shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12))),
      navigationBarTheme: NavigationBarThemeData(backgroundColor:panel,
        indicatorColor:copper.withOpacity(.22),
        labelTextStyle:WidgetStateProperty.all(textTheme.bodySmall)),
      snackbarTheme: const SnackBarThemeData(backgroundColor: panelAlt,contentTextStyle:TextStyle(color:cream)),
      dialogTheme: DialogThemeData(backgroundColor:panel,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18),side:const BorderSide(color:border))),
    );
  }
}
