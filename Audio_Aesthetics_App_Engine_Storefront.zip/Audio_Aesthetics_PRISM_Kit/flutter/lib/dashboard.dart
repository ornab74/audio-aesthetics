import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'prism_palette.dart';
import 'monitor.dart';

const copper=OrbitPalette.copper,teal=OrbitPalette.teal,cream=OrbitPalette.cream;

class Dashboard extends StatefulWidget{
  final MonitorState state;
  const Dashboard({super.key,required this.state});
  @override State<Dashboard> createState()=>_DashboardState();
}
class _DashboardState extends State<Dashboard>{
  final search=TextEditingController();
  final instruction=TextEditingController();
  final customName=TextEditingController();
  late final TextEditingController server,token,pro,bpm,reference,quiet;
  String category='all';
  @override void initState(){
    super.initState();final s=widget.state;
    server=TextEditingController(text:s.server);token=TextEditingController(text:s.serverToken);
    pro=TextEditingController(text:s.proToken);bpm=TextEditingController();
    reference=TextEditingController();quiet=TextEditingController(text:'-37');
    search.addListener(_refresh);
  }
  void _refresh(){if(mounted)setState((){});}
  @override void dispose(){for(final c in [search,instruction,customName,server,token,pro,bpm,reference,quiet]){c.dispose();}super.dispose();}
  @override Widget build(BuildContext context)=>AnimatedBuilder(animation:widget.state,builder:(context,_){
    final s=widget.state;final wide=MediaQuery.sizeOf(context).width>900;
    return Scaffold(backgroundColor:OrbitPalette.bg,body:SafeArea(child:Column(children:[
      _toolbar(s,wide),Expanded(child:SingleChildScrollView(child:Center(child:ConstrainedBox(
        constraints:const BoxConstraints(maxWidth:1400),child:Padding(padding:EdgeInsets.all(wide?28:14),child:Column(
        crossAxisAlignment:CrossAxisAlignment.start,children:[
        _hero(s,wide),const SizedBox(height:24),
        if(wide)Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Expanded(flex:7,child:Column(children:[_audioMeters(s),const SizedBox(height:18),_alerts(s)])),
          const SizedBox(width:18),Expanded(flex:5,child:_settings(s))
        ])else Column(children:[_audioMeters(s),const SizedBox(height:16),_alerts(s),const SizedBox(height:16),_settings(s)]),
        const SizedBox(height:22),_detections(s),const SizedBox(height:20),
        _custom(s),const SizedBox(height:22),_footer(s)
      ]))))))
    ])));
  });

  Widget _toolbar(MonitorState s,bool wide)=>Container(padding:EdgeInsets.symmetric(horizontal:wide?26:14,vertical:12),
    decoration:const BoxDecoration(color:OrbitPalette.panel,border:Border(bottom:BorderSide(color:OrbitPalette.border))),
    child:Row(children:[Container(width:37,height:37,decoration:BoxDecoration(shape:BoxShape.circle,
      border:Border.all(color:copper,width:2)),child:const Icon(Icons.graphic_eq,color:copper,size:21)),
      const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('AUDIO AESTHETICS',style:Theme.of(context).textTheme.titleLarge?.copyWith(color:cream,letterSpacing:1)),
        Text('HUMOID // PRISM • THE EARS BEHIND THE MIX',style:Theme.of(context).textTheme.bodySmall?.copyWith(color:teal,fontSize:10))
      ])),
      if(wide)const Padding(padding:EdgeInsets.only(right:14),child:_Tag('LOCAL-FIRST','FREE / GPL-3.0')),
      Icon(s.active?Icons.sensors:Icons.sensors_off,color:s.active?teal:OrbitPalette.muted),
      const SizedBox(width:5),Text(s.active?'LIVE':'OFFLINE',style:TextStyle(color:s.active?teal:OrbitPalette.muted))
    ]));

  Widget _hero(MonitorState s,bool wide)=>Container(width:double.infinity,padding:EdgeInsets.all(wide?30:20),
    decoration:BoxDecoration(borderRadius:BorderRadius.circular(22),
      border:Border.all(color:s.events.isNotEmpty&&s.active?copper:OrbitPalette.border),
      gradient:const LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,
        colors:[Color(0xFF213B33),Color(0xFF10211F),Color(0xFF151C23)])),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[const Icon(Icons.circle,color:teal,size:8),const SizedBox(width:7),
        const Expanded(child:Text('LIVE MONITOR  /  DECISION INTELLIGENCE',style:TextStyle(
          fontSize:11,color:teal,letterSpacing:1.3,fontWeight:FontWeight.w800))),
        Text('ENGINE v0.1',style:Theme.of(context).textTheme.bodySmall)]),
      const SizedBox(height:16),Text('Hear the problem.\nBefore the audience does.',
        style:Theme.of(context).textTheme.displayMedium?.copyWith(fontSize:wide?35:26,height:1.2)),
      const SizedBox(height:12),const Text('Continuous signal forensics + optional Clef-Omni multimodal judgment. Silent warnings for streams, studios and stages.',
        style:TextStyle(color:OrbitPalette.muted,height:1.6,fontSize:13)),
      const SizedBox(height:20),Wrap(spacing:10,runSpacing:10,children:[
        FilledButton.icon(icon:Icon(s.active?Icons.stop_circle_outlined:Icons.mic),
          onPressed:s.starting?null:(){if(s.active){s.stop();}else{s.start();}},
          label:Text(s.starting?'CONNECTING...':s.active?'STOP MONITOR':'START LISTENING')),
        OutlinedButton.icon(onPressed:s.active?null:()=>s.refreshCatalog(),icon:const Icon(Icons.sync),label:const Text('CHECK LOCAL ENGINE')),
        const _Tag('NO AUDIO STORED','PRIVACY FIRST')
      ]),
      if(s.error.isNotEmpty)Padding(padding:const EdgeInsets.only(top:13),child:Text(s.error,
          style:const TextStyle(color:Colors.orangeAccent,fontSize:12))),
      const SizedBox(height:16),Text('Source: device microphone. To listen to the actual OBS/program output, run the included system-loopback capture bridge.',
        style:const TextStyle(fontSize:11,color:OrbitPalette.gold))
    ]));

  Widget _audioMeters(MonitorState s)=>_Panel(title:'REALTIME AUDIO TELEMETRY',subtitle:'Fast DSP • overlapping 2s windows / 0.5s hops',
    child:Column(children:[
      SizedBox(height:150,width:double.infinity,child:CustomPaint(painter:WaveChart(s.history,s.active))),
      const SizedBox(height:16),Row(children:[
        Expanded(child:_stat('PEAK',s.peak,'dBFS',-20,0)),const SizedBox(width:12),
        Expanded(child:_stat('RMS',s.rms,'dBFS',-45,-6)),
      ]),const SizedBox(height:12),Row(children:[
        Expanded(child:_miniStat('CLIPPING','${s.clipped.toStringAsFixed(2)}%')),
        const SizedBox(width:12),Expanded(child:_miniStat('LISTENED','${s.seconds.toStringAsFixed(1)} s')),
        const SizedBox(width:12),Expanded(child:_miniStat('WARNINGS','${s.receivedAlerts}')),
      ]),const SizedBox(height:13),Row(children:[
        Expanded(child:_miniStat('SIGNAL HEALTH','${s.metrics['signal_health_score']??'—'} / 100')),
        const SizedBox(width:12),Expanded(child:_miniStat('CLEF AESTHETICS',
          s.aiScore==null?'NOT SCORED':'${s.aiScore!.toStringAsFixed(0)} / 100'))
      ]),const SizedBox(height:13),const Text(
        'Signal health is a heuristic technical index. Clef aesthetics is an uncalibrated AI opinion, not a mastering-grade measurement.',
        style:TextStyle(fontSize:11,color:OrbitPalette.muted))
    ]));

  Widget _stat(String name,double value,String unit,double low,double high){
    final progress=((value-low)/(high-low)).clamp(0.,1.);
    final color=progress>.9?copper:teal;
    return Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:OrbitPalette.panelAlt,borderRadius:BorderRadius.circular(12)),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(name,style:const TextStyle(color:OrbitPalette.muted,fontSize:10,letterSpacing:1.2)),
        const SizedBox(height:6),Text('${value.toStringAsFixed(1)} $unit',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:cream)),
        const SizedBox(height:9),ClipRRect(borderRadius:BorderRadius.circular(4),
        child:LinearProgressIndicator(value:progress,minHeight:6,backgroundColor:OrbitPalette.border.withOpacity(.3),valueColor:AlwaysStoppedAnimation(color)))
      ]));
  }
  Widget _miniStat(String name,String value)=>Container(padding:const EdgeInsets.all(12),
    decoration:BoxDecoration(color:OrbitPalette.panelAlt,borderRadius:BorderRadius.circular(10)),
    child:Column(children:[Text(name,style:const TextStyle(color:OrbitPalette.muted,fontSize:9)),const SizedBox(height:5),
      Text(value,style:const TextStyle(color:cream,fontWeight:FontWeight.w700,fontSize:14))]));

  Widget _alerts(MonitorState s)=>_Panel(title:'SILENT WARNING SYSTEM',subtitle:'Hysteresis • cooldown • optional local OSC light hook',
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Container(width:double.infinity,padding:const EdgeInsets.all(14),
        decoration:BoxDecoration(color:s.events.isNotEmpty?copper.withOpacity(.15):teal.withOpacity(.10),
          border:Border.all(color:s.events.isNotEmpty?copper:teal),borderRadius:BorderRadius.circular(11)),
        child:Row(children:[Icon(s.events.isEmpty?Icons.check_circle_outline:Icons.warning_amber_rounded,
          color:s.events.isEmpty?teal:copper),const SizedBox(width:10),Expanded(child:Text(
          s.events.isEmpty?'No triggered warning yet':'${s.events.first.label.toUpperCase()} • ${s.events.first.severity}',
          style:const TextStyle(fontWeight:FontWeight.bold)))])),
      const SizedBox(height:9),if(s.events.isEmpty)const Padding(padding:EdgeInsets.symmetric(vertical:14),
        child:Text('When a sustained audio problem is confirmed, warnings appear here without an audible alarm.',
          style:TextStyle(color:OrbitPalette.muted))),
      ...s.events.take(6).map((e)=>Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Row(children:[
        Icon(e.severity=='critical'?Icons.error_outline:Icons.info_outline,color:e.severity=='critical'?copper:OrbitPalette.gold,size:17),
        const SizedBox(width:9),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(e.label,style:const TextStyle(color:cream,fontWeight:FontWeight.w700)),
          Text('${e.source.toUpperCase()} • ${e.message}',maxLines:2,overflow:TextOverflow.ellipsis,
             style:const TextStyle(fontSize:10,color:OrbitPalette.muted))])),
        Text('${e.time.hour.toString().padLeft(2,'0')}:${e.time.minute.toString().padLeft(2,'0')}',
          style:const TextStyle(fontSize:10,color:OrbitPalette.muted)),
      ]))),
    ]));

  Widget _settings(MonitorState s)=>_Panel(title:'PATCH BAY / CONFIG',subtitle:'Define what your monitoring engine hears',child:
    Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('MONITOR PRESET',style:TextStyle(color:teal,fontSize:10,letterSpacing:1.4)),const SizedBox(height:8),
      DropdownButtonFormField<String>(value:s.preset,items:MonitorState.fallback.keys.map(
        (k)=>DropdownMenuItem(value:k,child:Text(k.toUpperCase()))).toList(),onChanged:s.active?null:(k){if(k!=null)s.selectPreset(k);}),
      const SizedBox(height:16),const Text('AI DECISION BACKEND',style:TextStyle(color:teal,fontSize:10,letterSpacing:1.4)),
      const SizedBox(height:8),DropdownButtonFormField<String>(value:s.clef,
        items:const [DropdownMenuItem(value:'off',child:Text('Signal DSP only (offline)')),
          DropdownMenuItem(value:'local',child:Text('Local Clef-Omni (FOSS)')),
          DropdownMenuItem(value:'cloud',child:Text('Cloud Clef-Omni (Pro)'))],
        onChanged:s.active?null:(v){if(v!=null)s.set('clef',v);}),
      const SizedBox(height:10),Text(s.clef=='off'?'AI judgments are disabled. DSP checks still work.':
        'AI analyzes ~10-second overlapping windows every ~8 seconds. It needs a Clef-Omni server or configured cloud credentials.',
        style:const TextStyle(fontSize:11,color:OrbitPalette.gold)),
      const SizedBox(height:17),_field('LOCAL ENGINE URL',server,onChanged:(v)=>s.set('server',v),enabled:!s.active),
      const SizedBox(height:10),_field('LOCAL ACCESS TOKEN (OPTIONAL)',token,onChanged:(v)=>s.set('token',v),enabled:!s.active,hide:true),
      if(s.clef=='cloud')...[const SizedBox(height:10),_field('PRO LICENSE TOKEN',pro,onChanged:(v)=>s.set('pro',v),enabled:!s.active,hide:true)],
      const SizedBox(height:12),Wrap(spacing:10,runSpacing:10,children:[
        SizedBox(width:105,child:_field('BPM (OPT)',bpm,enabled:!s.active,numeric:true,
          onChanged:(v){s.bpm=double.tryParse(v)??0;})),
        SizedBox(width:119,child:_field('PITCH Hz',reference,enabled:!s.active,numeric:true,
          onChanged:(v){s.referenceHz=double.tryParse(v)??0;})),
        SizedBox(width:118,child:_field('QUIET dBFS',quiet,enabled:!s.active,numeric:true,
          onChanged:(v){s.quietDb=double.tryParse(v)??-37;})),
      ]),const SizedBox(height:10),const Text('Beat drift requires BPM. Pitch reference requires a mostly isolated note; polyphonic tuning judgments need the AI backend.',
        style:TextStyle(fontSize:10,color:OrbitPalette.muted)),
    ]));

  Widget _field(String name,TextEditingController ctrl,{required ValueChanged<String> onChanged,bool enabled=true,bool hide=false,bool numeric=false})=>
    Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(name,style:const TextStyle(fontSize:9,color:OrbitPalette.muted,letterSpacing:1.1)),
      const SizedBox(height:6),TextField(controller:ctrl,enabled:enabled,obscureText:hide,
        keyboardType:numeric?const TextInputType.numberWithOptions(decimal:true,signed:true):TextInputType.text,
        onChanged:onChanged,style:const TextStyle(fontSize:12),decoration:const InputDecoration(isDense:true)),
    ]);

  Widget _detections(MonitorState s){
    final filtered=s.detectors.where((d){
      final ok=category=='all'||d.layer==category;
      final q=search.text.toLowerCase();return ok && (d.label.toLowerCase().contains(q)||d.description.toLowerCase().contains(q));
    }).toList();
    return _Panel(title:'DETECTION MATRIX',subtitle:'${s.selected.length} enabled of ${s.detectors.length} built-in detectors • individual toggles',
      child:Column(children:[
        Row(children:[Expanded(child:TextField(controller:search,
          decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Find feedback, vocal, clipping, timing...',isDense:true))),
          const SizedBox(width:10),DropdownButton<String>(value:category,items:const [
              DropdownMenuItem(value:'all',child:Text('ALL')),DropdownMenuItem(value:'signal',child:Text('DSP')),
              DropdownMenuItem(value:'ai',child:Text('CLEF'))],
            onChanged:(v){setState((){category=v??'all';});})]),
        const SizedBox(height:10),Wrap(spacing:9,runSpacing:9,children:filtered.map((d)=>
          SizedBox(width:310,child:Container(padding:const EdgeInsets.fromLTRB(11,8,5,8),
            decoration:BoxDecoration(color:OrbitPalette.panelAlt,borderRadius:BorderRadius.circular(10),
              border:Border.all(color:d.enabled?teal.withOpacity(.35):OrbitPalette.border.withOpacity(.3))),
            child:Row(children:[Icon(d.layer=='ai'?Icons.auto_awesome:Icons.multiline_chart,size:16,color:d.layer=='ai'?OrbitPalette.violet:teal),
              const SizedBox(width:9),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text(d.label,style:const TextStyle(color:cream,fontSize:12,fontWeight:FontWeight.w700)),
                Text(d.description,maxLines:1,overflow:TextOverflow.ellipsis,
                  style:const TextStyle(fontSize:9,color:OrbitPalette.muted))])),
              Switch.adaptive(value:d.enabled,onChanged:s.active?null:(v)=>s.toggle(d,v),activeColor:teal),
            ])))).toList())
      ]));
  }

  Widget _custom(MonitorState s)=>_Panel(title:'TEACH IT YOUR OWN FAILURE',
    subtitle:'Type a detectable audible fault in plain English • Clef scores it as a yes/no decision',
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Examples: “Is my vocal doubling flamming?”, “Does the snare suddenly disappear?”, “Does the stream sound underwater?”',
        style:TextStyle(color:OrbitPalette.gold,fontSize:12)),const SizedBox(height:12),
      TextField(controller:customName,enabled:!s.active,decoration:const InputDecoration(labelText:'Detector label',hintText:'E.g. Snare missing')),
      const SizedBox(height:8),TextField(controller:instruction,enabled:!s.active,minLines:2,maxLines:3,
        decoration:const InputDecoration(labelText:'What should the AI listen for?',
          hintText:'Is the snare drum missing or much quieter than the rest of the kit?')),
      const SizedBox(height:10),OutlinedButton.icon(icon:const Icon(Icons.add_circle_outline),
        onPressed:s.active?null:(){
          if(!s.addCustom(customName.text,instruction.text)){
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter at least 12 characters in the detection question.')));
          }else{customName.clear();instruction.clear();}
        },label:const Text('ADD CUSTOM DETECTOR')),
      const SizedBox(height:10),...s.custom.asMap().entries.map((entry)=>ListTile(dense:true,
        leading:const Icon(Icons.psychology,color:OrbitPalette.violet),
        title:Text('${entry.value['label']}'),subtitle:Text('${entry.value['question']}',maxLines:2),
        trailing:IconButton(onPressed:s.active?null:()=>s.removeCustom(entry.key),icon:const Icon(Icons.delete_outline)))),
      const Text('Custom detections require local/cloud Clef-Omni. Adding one does not train the model; it creates an explicit decision question.',
        style:TextStyle(fontSize:11,color:OrbitPalette.muted))
    ]));

  Widget _footer(MonitorState s)=>Padding(padding:const EdgeInsets.symmetric(vertical:13),
    child:Wrap(crossAxisAlignment:WrapCrossAlignment.center,spacing:18,runSpacing:10,children:[
      const Text('GPL-3.0 • LOCAL KIT • NO SECRET RECORDINGS',style:TextStyle(color:OrbitPalette.muted,fontSize:11)),
      TextButton.icon(onPressed:()=>launchUrl(Uri.parse('https://developers.cloudflare.com/workers-ai/models/clef-omni/')),
        icon:const Icon(Icons.open_in_new,size:13),label:const Text('CLEF-OMNI DOCUMENTATION')),
      TextButton.icon(onPressed:()=>launchUrl(Uri.parse('http://127.0.0.1:8788')),
        icon:const Icon(Icons.storefront,size:13),label:const Text('PRO • $20/MONTH'))
    ]));
}

class _Panel extends StatelessWidget{
  final String title,subtitle;final Widget child;
  const _Panel({required this.title,required this.subtitle,required this.child});
  @override Widget build(BuildContext context)=>Container(width:double.infinity,padding:const EdgeInsets.all(17),
    decoration:BoxDecoration(color:OrbitPalette.panel,borderRadius:BorderRadius.circular(16),
      border:Border.all(color:OrbitPalette.border.withOpacity(.7))),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(title,style:const TextStyle(color:cream,fontSize:14,fontWeight:FontWeight.bold,letterSpacing:1)),
      const SizedBox(height:4),Text(subtitle,style:const TextStyle(color:OrbitPalette.muted,fontSize:10)),
      const SizedBox(height:16),child
    ]));
}

class _Tag extends StatelessWidget{
  final String label,sub;const _Tag(this.label,this.sub);
  @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:8),
    decoration:BoxDecoration(color:OrbitPalette.panelAlt,borderRadius:BorderRadius.circular(9),
      border:Border.all(color:OrbitPalette.border)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,
      children:[Text(label,style:const TextStyle(color:teal,fontWeight:FontWeight.bold,fontSize:9)),
        Text(sub,style:const TextStyle(color:OrbitPalette.muted,fontSize:8))]));
}

class WaveChart extends CustomPainter{
  final List<double> levels;final bool live;
  WaveChart(this.levels,this.live);
  @override void paint(Canvas canvas,Size size){
    final grid=Paint()..color=OrbitPalette.border.withOpacity(.4)..strokeWidth=.6;
    for(int i=0;i<=4;i++){
      final y=size.height*i/4;canvas.drawLine(Offset(0,y),Offset(size.width,y),grid);
    }
    final paint=Paint()..color=live?teal:OrbitPalette.muted..strokeWidth=2.2
      ..style=PaintingStyle.stroke..strokeCap=StrokeCap.round;
    final trace=Path();
    for(int i=0;i<levels.length;i++){
      final x=i*size.width/math.max(1,levels.length-1);
      final norm=((levels[i]+80)/80).clamp(0.,1.);
      final y=size.height*(1-norm*.92)-3;
      if(i==0){trace.moveTo(x,y);}else{trace.lineTo(x,y);}
    }
    canvas.drawPath(trace,paint);
    final glow=Paint()..color=(live?teal:copper).withOpacity(.15)..strokeWidth=9
      ..style=PaintingStyle.stroke..maskFilter=const MaskFilter.blur(BlurStyle.normal,4);
    canvas.drawPath(trace,glow);
  }
  @override bool shouldRepaint(covariant WaveChart old)=>true;
}
