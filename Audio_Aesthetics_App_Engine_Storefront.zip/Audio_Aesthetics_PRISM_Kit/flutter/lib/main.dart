import 'package:flutter/material.dart';
import 'prism_palette.dart';
import 'monitor.dart';
import 'dashboard.dart';
void main(){WidgetsFlutterBinding.ensureInitialized();runApp(const AudioAestheticsApp());}
class AudioAestheticsApp extends StatefulWidget{
  const AudioAestheticsApp({super.key});
  @override State<AudioAestheticsApp> createState()=>_AudioAestheticsAppState();
}
class _AudioAestheticsAppState extends State<AudioAestheticsApp>{
  final engine=MonitorState();
  @override void dispose(){engine.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>MaterialApp(
    title:'AUDIO AESTHETICS // PRISM',debugShowCheckedModeBanner:false,
    theme:OrbitPalette.theme(),home:Dashboard(state:engine));
}
