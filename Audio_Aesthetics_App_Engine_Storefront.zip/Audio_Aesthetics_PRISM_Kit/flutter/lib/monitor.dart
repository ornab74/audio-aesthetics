import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:record/record.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class MonitorEvent {
  final String id,label,message,source,severity;
  final double probability;
  final DateTime time;
  const MonitorEvent(this.id,this.label,this.message,this.source,this.severity,this.probability,this.time);
  factory MonitorEvent.fromMap(Map<String,dynamic> m)=>MonitorEvent(
    '${m['id']??'event'}','${m['label']??'Check'}','${m['message']??''}',
    '${m['source']??'dsp'}','${m['severity']??'warning'}',
    (m['probability'] as num?)?.toDouble()??1,DateTime.now());
}

class DetectOption {
  final String id,label,description,layer;
  bool enabled;
  DetectOption(this.id,this.label,this.description,this.layer,{this.enabled=false});
  factory DetectOption.fromMap(Map<String,dynamic> m)=>DetectOption(
    '${m['id']}','${m['label']}','${m['description']}','${m['layer']}');
}

class MonitorState extends ChangeNotifier {
  static const fallback = <String,List<String>>{
    'streamer':['clip','too_quiet','too_loud','silence','dropout','level_jump','feedback','distorted_voice','echo','noise_floor','unbalanced_mix'],
    'artist':['clip','too_loud','harsh','muddy','smear','buried_vocal','vocal_hot','offbeat','unbalanced_mix','reverb_wash','music_aesthetics'],
    'guitar':['clip','tuning_reference','harsh','detuned_guitar','offbeat','reverb_wash','click_pop'],
    'vocals':['clip','too_quiet','too_loud','harsh','sibilance','buried_vocal','vocal_hot','distorted_voice','voice_fatigue','reverb_wash'],
    'levels':['clip','too_quiet','too_loud','silence','dropout','dc_offset','overcompressed','level_jump','phase','rumble'],
    'concert':['clip','silence','dropout','phase','level_jump','feedback','crowd_swallow','monitor_bleed','buried_vocal','room_resonance'],
    'podcast':['clip','too_quiet','too_loud','silence','dropout','noise_floor','echo','distorted_voice','click_pop'],
    'dj':['clip','too_loud','overcompressed','phase','smear','offbeat','unbalanced_mix','click_pop'],
    'mastering':['clip','overcompressed','harsh','muddy','rumble','phase','unbalanced_mix','music_aesthetics'],
    'custom':['clip','too_quiet','silence','dropout'],
  };
  String server='http://127.0.0.1:8788';
  String serverToken='',proToken='';
  String preset='streamer',clef='off',status='IDLE',error='';
  bool active=false,starting=false,connected=false;
  double seconds=0,bpm=0,referenceHz=0,quietDb=-37;
  double? aiScore;
  int receivedAlerts=0;
  Map<String,dynamic> metrics={};
  final List<MonitorEvent> events=[];
  final List<double> history=List.filled(80,-65.0);
  List<DetectOption> detectors=[];
  List<Map<String,dynamic>> custom=[];
  WebSocketChannel? _channel;
  final AudioRecorder _recorder=AudioRecorder();
  StreamSubscription<dynamic>? _socketSub;
  StreamSubscription<Uint8List>? _audioSub;
  List<String> get selected=>detectors.where((d)=>d.enabled).map((d)=>d.id).toList();
  double get peak=>(metrics['peak_dbfs'] as num?)?.toDouble()??-75;
  double get rms=>(metrics['rms_dbfs'] as num?)?.toDouble()??-75;
  double get clipped=>(metrics['clipping_pct'] as num?)?.toDouble()??0;

  MonitorState(){_localCatalog();refreshCatalog();}
  void _localCatalog(){
    const names=<String,String>{
      'clip':'Clipping','too_quiet':'Too quiet','too_loud':'Too loud','silence':'Unexpected silence',
      'dropout':'Dropouts','dc_offset':'DC offset','overcompressed':'Overcompressed',
      'harsh':'Harsh / brittle','muddy':'Muddy / boomy','rumble':'Low rumble',
      'phase':'Stereo phase risk','smear':'Transient smear','sibilance':'Sibilance',
      'level_jump':'Level jump','onset_grid':'Beat grid drift','tuning_reference':'Tuning reference',
      'buried_vocal':'Buried vocals','vocal_hot':'Vocals too high','distorted_voice':'Vocal distortion',
      'detuned_guitar':'Detuned guitar','offbeat':'Offbeat performance',
      'unbalanced_mix':'Unbalanced mix','reverb_wash':'Reverb wash','feedback':'Feedback howl',
      'monitor_bleed':'Monitor bleed','click_pop':'Clicks & pops','room_resonance':'Room resonance',
      'crowd_swallow':'Crowd masking','voice_fatigue':'Harsh vocals',
      'noise_floor':'Background noise','echo':'Unwanted echo','music_aesthetics':'Audio aesthetics warning',
    };
    const ai={'buried_vocal','vocal_hot','distorted_voice','detuned_guitar','offbeat',
      'unbalanced_mix','reverb_wash','feedback','monitor_bleed','click_pop','room_resonance',
      'crowd_swallow','voice_fatigue','noise_floor','echo','music_aesthetics'};
    detectors=names.entries.map((e)=>DetectOption(e.key,e.value,
      ai.contains(e.key)?'CLEF / subjective listening':'Instant local signal analysis',
      ai.contains(e.key)?'ai':'signal',enabled:fallback[preset]!.contains(e.key))).toList();
  }
  Future<void> refreshCatalog()async{
    try{
      final url=Uri.parse('$server/api/presets');
      final response=await http.get(url).timeout(const Duration(seconds:3));
      if(response.statusCode!=200)return;
      final data=jsonDecode(response.body) as Map<String,dynamic>;
      final checks=(data['detections'] as List).map((e)=>DetectOption.fromMap(Map<String,dynamic>.from(e))).toList();
      final chosen=selected;
      detectors=checks;
      for(final d in detectors){d.enabled=chosen.contains(d.id);}
      connected=true;notifyListeners();
    }catch(_){connected=false;notifyListeners();}
  }
  void selectPreset(String p){
    if(active || !fallback.containsKey(p))return;
    preset=p;
    for(final d in detectors){d.enabled=fallback[p]!.contains(d.id);}
    notifyListeners();
  }
  void toggle(DetectOption d,bool enabled){if(active)return;d.enabled=enabled;notifyListeners();}
  void set(String field,String value){
    if(active)return;
    switch(field){case 'server':server=value;break;case 'token':serverToken=value;break;
      case 'pro':proToken=value;break;case 'clef':clef=value;break;}
    notifyListeners();
  }
  bool addCustom(String label,String question){
    if(active || question.trim().length<12 || custom.length>=32)return false;
    custom.add({'label':label.trim().isEmpty?'Custom check':label.trim(),
      'question':question.trim(),'threshold':.7});notifyListeners();return true;
  }
  void removeCustom(int i){if(!active && i>=0 && i<custom.length){custom.removeAt(i);notifyListeners();}}
  Future<void> start()async{
    if(active || starting)return;
    starting=true;error='';status='CONNECTING';notifyListeners();
    try{
      final u=Uri.parse(server.trim());
      if(u.userInfo.isNotEmpty || u.query.isNotEmpty || u.fragment.isNotEmpty || u.path.isNotEmpty ||
         !(u.scheme=='https' || (u.scheme=='http' && ['localhost','127.0.0.1','::1'].contains(u.host)))){
        throw StateError('Use HTTPS outside localhost. Never send microphone audio over remote HTTP.');
      }
      if(!await _recorder.hasPermission())throw StateError('Microphone permission was denied');
      final wsUri=u.replace(scheme:u.scheme=='https'?'wss':'ws',path:'/ws/audio');
      _channel=WebSocketChannel.connect(wsUri);
      await _channel!.ready.timeout(const Duration(seconds:8));
      _socketSub=_channel!.stream.listen(_onMessage,onError:(Object err){error='$err';status='DISCONNECTED';active=false;notifyListeners();},
          onDone:(){if(active){status='DISCONNECTED';active=false;notifyListeners();}});
      _channel!.sink.add(jsonEncode({'type':'start','token':serverToken,'pro_token':proToken,
        'sample_rate':16000,'channels':1,'preset':preset,'clef':clef,
        'enabled':selected,'custom':custom,
        'bpm':bpm>0?bpm:null,'reference_hz':referenceHz>0?referenceHz:null,'quiet_db':quietDb}));
      final stream=await _recorder.startStream(const RecordConfig(encoder:AudioEncoder.pcm16bits,
        sampleRate:16000,numChannels:1,autoGain:false,echoCancel:false,noiseSuppress:false));
      _audioSub=stream.listen((bytes){_channel?.sink.add(bytes);},onError:(Object e){error='Recorder: $e';status='RECORDER ERROR';notifyListeners();});
      active=true;status='LISTENING';notifyListeners();
    }catch(e){error='$e';status='FAILED';await stop();}
    finally{starting=false;notifyListeners();}
  }
  void _onMessage(dynamic msg){
    if(msg is! String)return;
    try{
      final Map<String,dynamic> m=Map<String,dynamic>.from(jsonDecode(msg));
      switch(m['type']){
        case 'ready':status='LIVE • ${m['preset'].toString().toUpperCase()}';break;
        case 'meters':
          seconds=(m['seconds'] as num?)?.toDouble()??seconds;
          metrics=Map<String,dynamic>.from(m['metrics'] as Map? ?? {});
          history.removeAt(0);history.add(rms.clamp(-80.,0.));break;
        case 'alert':events.insert(0,MonitorEvent.fromMap(m));receivedAlerts++;
          if(events.length>60)events.removeLast();break;
        case 'ai_score':aiScore=(m['score_100'] as num?)?.toDouble();break;
        case 'ai_error':error='AI temporarily unavailable: ${m['message']}';break;
        case 'error':error='${m['message']}';status='ERROR';Future<void>.microtask(stop);break;
      }
      notifyListeners();
    }catch(_){/* Ignore malformed/unknown telemetry frames. */}
  }
  Future<void> stop()async{
    active=false;
    final audio=_audioSub;_audioSub=null;await audio?.cancel();
    try{await _recorder.stop();}catch(_){ }
    final socket=_socketSub;_socketSub=null;await socket?.cancel();
    await _channel?.sink.close();_channel=null;
    status='IDLE';notifyListeners();
  }
  @override void dispose(){_audioSub?.cancel();_socketSub?.cancel();_channel?.sink.close();_recorder.dispose();super.dispose();}
}
